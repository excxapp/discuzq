<?php

/**
 * Discuz & Tencent Cloud
 * This is NOT a freeware, use is subject to license terms
 */

namespace App\MessageTemplate;

/**
 * 内容审核不通过通知
 *
 * Class PostModMessage
 * @package App\MessageTemplate
 */
class PostModMessage extends BasePostMessage
{
    protected $tplId = 4;
}
