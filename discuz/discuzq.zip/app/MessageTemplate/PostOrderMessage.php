<?php

/**
 * Discuz & Tencent Cloud
 * This is NOT a freeware, use is subject to license terms
 */

namespace App\MessageTemplate;

/**
 * 内容置顶通知
 *
 * Class PostOrderMessage
 * @package App\MessageTemplate
 */
class PostOrderMessage extends BasePostMessage
{
    protected $tplId = 8;
}
