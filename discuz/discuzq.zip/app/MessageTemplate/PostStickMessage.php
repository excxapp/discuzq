<?php

/**
 * Discuz & Tencent Cloud
 * This is NOT a freeware, use is subject to license terms
 */

namespace App\MessageTemplate;

/**
 * 内容精华通知
 *
 * Class PostStickMessage
 * @package App\MessageTemplate
 */
class PostStickMessage extends BasePostMessage
{
    protected $tplId = 7;
}
