<?php

/**
 * Discuz & Tencent Cloud
 * This is NOT a freeware, use is subject to license terms
 */

namespace App\MessageTemplate;

/**
 * 内容审核通过通知
 *
 * Class PostThroughMessage
 * @package App\MessageTemplate
 */
class PostThroughMessage extends BasePostMessage
{
    protected $tplId = 5;
}
