<?php

/**
 * Discuz & Tencent Cloud
 * This is NOT a freeware, use is subject to license terms
 */

namespace App\MessageTemplate;

/**
 * 内容修改通知
 *
 * Class PostMessage
 * @package App\MessageTemplate
 */
class PostMessage extends BasePostMessage
{
    protected $tplId = 9;
}
